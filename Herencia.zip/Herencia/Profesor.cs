class Profesor:Persona{
public string depart{get;set;}
public Profesor (string NameApellido, double cedula, string statusCivil, string depart):base(NameApellido,cedula,statusCivil){
    this.depart=depart;
}
public void cambiodepart(){
    string newDepart;
    Console.WriteLine("Ingrese el nuevo departamento");
    newDepart=Console.ReadLine();
    Console.WriteLine("El nuevo departamento es : "+ newDepart);
    depart=newDepart;
    



}
    public override void imprimir()
    {
       Console.WriteLine("datos del profesor");
        cambiarstatus();
        cambiodepart();

        Console.WriteLine("nombre "+NameApellido);
        Console.WriteLine("numero de cedula "+cedula);
        Console.WriteLine("estado civil "+statusCivil);
        Console.WriteLine("departamento del profesor:"+depart);
    
         Console.ReadLine(); 



    }
}

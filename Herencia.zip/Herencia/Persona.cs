class Persona{
public string NameApellido{get;set;}
public double cedula{get;set;}
public string statusCivil{get;set;}
public Persona (string NameApellido, double cedula, string statusCivil){
    this.NameApellido= NameApellido;
    this.cedula= cedula;
    this.statusCivil=statusCivil;

}
public void cambiarstatus(){
    string actv=("");
    Console.WriteLine("¿Quiere cambiar su estado civil?");
    actv=Console.ReadLine();
    if (actv=="si"|| actv=="si"){
        string newStatus;
        Console.WriteLine("Escriba el nuevo estado civil ");
        newStatus=Console.ReadLine();
        Console.WriteLine("El nuevo estado civil es : "+newStatus);
        statusCivil=newStatus;

    }
    Console.ReadLine();

}
public virtual void imprimir(){
    
}


}
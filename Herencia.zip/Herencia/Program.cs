﻿internal class Program{
private static void Main (string[] args){
List<Persona> lista=new List<Persona>();
lista.Add(new Estudiante("Juan Cevallos Garcia", 7486565565,"casado","matematicas A");)
lista.Add(new Profesor("Pedro Baldor Noñes", 748651515,"casado","Fisica ");)
lista.Add(new Empleado("Jesus Bailon Quijije", 748687485465,"casado","Asambleista ");)

}



}
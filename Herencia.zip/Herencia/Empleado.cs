class Empleado:Persona{
public int AñoI{get;set;}
public int nDespacho{get;set;}
public string secc{get;set;}
public Empleado (string NameApellido, double cedula, int AñoI, int nDespacho, string secc):base(NameApellido,cedula,statusCivil){
    this.AñoI=AñoI;
    this.nDespacho=nDespacho;
    this.secc=secc;

}
public void resigDespacho(){
    int newDespacho;
    Console.WriteLine("Ingrese el nuevo despacho");
    newDespacho=int.Parse(Console.ReadLine());
    Console.WriteLine("El nuevo despacho es : "+ secc);
    nDespacho=newDespacho;

}
public void cambioservice(){
    string newsecc;
    Console.WriteLine("Ingrese el servicio que remplazara");
    newsecc=Console.ReadLine();
    Console.WriteLine("El nuevo servicio es : "+ secc);
    secc=newsecc;


}
    public override void imprimir()
    {
        Console.WriteLine("datos del empleado");
        cambiarstatus();
        resigDespacho();
        cambioservice();
        Console.WriteLine("nombre "+NameApellido);
        Console.WriteLine("numero de cedula "+cedula);
        Console.WriteLine("estado civil "+statusCivil);
        Console.WriteLine("Año de ingreso: "+AñoI);
        Console.WriteLine("Numero de despacho: "+nDespacho);
        Console.WriteLine("servicio asignado: "+secc);
        Console.WriteLine("curso en el que fue matriculado "+Matricula);
    
         Console.ReadLine();
    }
}

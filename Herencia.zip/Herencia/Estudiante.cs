class Estudiante:Persona{
public string Matricula{get;set;}
public Estudiante (string NameApellido, double cedula, string statusCivil, string Matricula):base(NameApellido, cedula, statusCivil){
    this.Matricula=Matricula;
}
    public void cambcurso(){
        string newcurso;
        Console.WriteLine("Escriba el nuevo curso ");
        newcurso=Console.ReadLine();
        Console.WriteLine(" El nuevo curso es: "+newcurso);
        Matricula=newcurso;

    }
    public override void imprimir()
    {
      Console.WriteLine("Dats del estudiante");
      cambiarstatus();
      cambcurso();
      Console.WriteLine("nombre "+NameApellido);
     Console.WriteLine("numero de cedula "+cedula);
     Console.WriteLine("estado civil "+statusCivil);
     Console.WriteLine("curso en el que fue matriculado "+Matricula);
    
     Console.ReadLine();
}



}